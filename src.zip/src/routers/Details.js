import { useEffect } from "react";
import { findRenderedComponentWithType } from "react-dom/test-utils";
import React, { PureComponent } from 'react';
import { useParams } from "react-router-dom";
import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer,
    BarChart,
    Bar
} from "recharts";
import { render } from "@testing-library/react";
import './Details.css'




const data = [
    {
        name: '00:00', positive: 0, negative: 0, question: 0, neutrality: 0, total: 0,

    },
    {
        name: '01:00', positive: 509, negative: 113, question: 151, neutrality: 930, total: 1703,

    },
    {
        name: '02:00', positive: 1629, negative: 344, question: 260, neutrality: 930, total: 6185,
    },
    {
        name: '03:00', positive: 826, negative: 150, question: 128, neutrality: 1178, total: 8467,

    },
    {
        name: '04:00', positive: 1957, negative: 324, question: 279, neutrality: 2440, total: 13467,

    },
    {
        name: '05:00', positive: 2737, negative: 396, question: 288, neutrality: 3011, total: 19899,
    },
    {
        name: '06:00', positive: 2283, negative: 415, question: 272, neutrality: 3587, total: 29968,
    },
    {
        name: "07:00", positive: 799, negative: 130, question: 150, neutrality: 1333, total: 28868,
    },
    {
        name: '08:00', positive: 813, negative: 168, question: 244, neutrality: 1531, total: 31624,
    }



];

const bardata = [

    {
        name: "01:00",
        "number of viewers": 1500
    },
    {
        name: "02:00",
        "number of viewers": 10000
    },
    {
        name: "03:00",
        "number of viewers": 4300
    },
    {
        name: "04:00",
        "number of viewers": 6300
    }
];




const Chart = () => {


    return (

        <LineChart
            width={500}
            height={300}
            data={data}
            margin={{
                top: 5, right: 30, left: 20, bottom: 5,
            }}
        >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="positive" stroke="#3a7bd5" activeDot={{ r: 8 }} /> //stroke : 선의 색상, activeDot : 그래프에 마우스를 올릴 시 원의 스타일 설정
            <Line type="monotone" dataKey="negative" stroke="#ef473a" />
            <Line type="monotone" dataKey="question" stroke="#7F00FF" />
            <Line type="monotone" dataKey="neutrality" stroke="#d9a7c7" />


        </LineChart>



    );
}
const Barchartt = () => {
    return (
        <BarChart width={500} height={300} data={bardata}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="number of viewers" fill="#8884d8" />

        </BarChart>
    );
}





function Details() {
    return (
        <div>
            <div className="container">
                <div className="title">
                    <h1>{"<시간대별 채팅 감정 분석>"}</h1>
                </div>
                <div className="title1 ">
                    <h1>{"<시간대별 시청자 수>"}</h1>
                </div>
            </div>
            <div className="container">
                <div>{Chart()}</div>
                <div className="Barchartt">{Barchartt()}</div>
            </div>
            <div><h5 className="notice"> notice: 경과된 시간을 기준으로 함 </h5></div>



        </div>



    )
}

export default Details